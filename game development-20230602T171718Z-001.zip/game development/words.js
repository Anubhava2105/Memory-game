const words = [
    {
        word: "anubhava",
        hint:"game developer"
    },
    {
        word: "Motu",
        hint:"paneer lover"
    },
    {
        word: "tanmay",
        hint:"confusion"
    },
    {
        word: "Dhairya",
        hint:"hotspot"
    },
]